package com.rajgor.heritage;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebSettings;
import android.webkit.JavascriptInterface;
import android.content.Intent;
import android.net.Uri;
import android.database.Cursor;
import android.provider.OpenableColumns;
import java.io.*;

public class MainActivity extends Activity {
    WebView web;
    static final int PICK_IMPORT = 21, CREATE_EXPORT = 22;
    String pendingExport = "";
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        web.setWebChromeClient(new WebChromeClient());
        web.addJavascriptInterface(new Bridge(), "AndroidBridge");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }
    class Bridge {
        @JavascriptInterface public void exportJson(String data) {
            pendingExport = data;
            runOnUiThread(() -> {
                Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("application/json");
                i.putExtra(Intent.EXTRA_TITLE, "Rajgor_Family_Backup.json");
                startActivityForResult(i, CREATE_EXPORT);
            });
        }
        @JavascriptInterface public void importJson() {
            runOnUiThread(() -> {
                Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                startActivityForResult(i, PICK_IMPORT);
            });
        }
    }
    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null) return;
        Uri uri = data.getData();
        try {
            if (requestCode == CREATE_EXPORT) {
                try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                    out.write(pendingExport.getBytes("UTF-8"));
                }
            } else if (requestCode == PICK_IMPORT) {
                StringBuilder sb = new StringBuilder();
                try (InputStream in = getContentResolver().openInputStream(uri);
                     BufferedReader r = new BufferedReader(new InputStreamReader(in, "UTF-8"))) {
                    String line; while ((line = r.readLine()) != null) sb.append(line);
                }
                final String json = sb.toString();
                web.evaluateJavascript("window.importBackupFromAndroid(" +
                    org.json.JSONObject.quote(json) + ")", null);
            }
        } catch (Exception e) { e.printStackTrace(); }
    }
}
