# Rajgor Family Heritage (Android starter project)

This is an offline Android WebView app project. It stores family entries locally on the device and supports JSON backup/export and additive import (existing records are retained; duplicate IDs are skipped).

## Build
Run `gradle assembleDebug` with JDK 17 and Android SDK platform 35 installed, or use the included GitHub Actions workflow:
1. Upload the contents of this folder to a GitHub repository's `main` branch.
2. Open the repository's Actions tab.
3. Select `Build Android APK` and press `Run workflow` (or wait for the first push build).
4. Open the completed run and download the `Rajgor-Family-Heritage-APK` artifact.
5. Extract the ZIP and install `app-debug.apk` on Android.

## Important
This is an initial working starter, not the full requested family-tree product. It currently provides member records, relation-to-member linking, dates, notes, search, offline storage, and additive JSON backup import. It does not yet provide a graphical expandable ancestry tree, photo attachments, Windows EXE, or multi-device automatic sync. Backups must be shared manually.
